import 'package:flutter/material.dart';

class NotificationHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
