
import 'package:flutter/material.dart';
import 'package:turing_academy/constants/appStrings.dart';
class ContactDeveloperSupport extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text(AppString.pleaseContactDeveloperSupport)),

    );
  }
}
