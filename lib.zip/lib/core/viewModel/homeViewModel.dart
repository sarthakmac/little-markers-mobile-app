//
//import 'package:flutter/material.dart';
//import 'package:get_it/get_it.dart';
//
//import 'package:turing_academy/core/viewModel/baseModel.dart';
//
//
//GetIt getIt = GetIt.instance;
//
//class HomeViewModel extends BaseModel {
//  GlobalKey<ScaffoldState> scaffoldkey = GlobalKey();
//
//}
