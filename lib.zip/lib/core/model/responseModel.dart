import 'package:flutter/cupertino.dart';

class ResponseModel {
  final bool isSUcessfull;
  final String responseMessage;

  ResponseModel({@required this.isSUcessfull, @required this.responseMessage});
}
