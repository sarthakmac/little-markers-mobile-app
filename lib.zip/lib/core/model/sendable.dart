abstract class Sendable {
  Map<String, dynamic> toJson();
}
