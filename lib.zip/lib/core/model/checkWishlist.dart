class CheckwishList{
  int status;
  bool exist;
  CheckwishList({this.status,this.exist});
}