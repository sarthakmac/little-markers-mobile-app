
class StarterValues{
  bool isAvailable;
  bool isLogin;
  StarterValues({this.isAvailable,this.isLogin});
}