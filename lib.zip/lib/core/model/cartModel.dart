import 'package:flutter/material.dart';
import 'package:turing_academy/core/model/productModel.dart';
import 'package:turing_academy/models/product.dart';

class CartModel {
  int quantity;
  ProductModel product;
}
//
//class CartCollection {
//  final int id;
//  final CartModel cartModel;
//
//  CartCollection({@required this.id, @required this.cartModel});
//}
